import { Link } from "react-router";
import { motion } from "framer-motion";
import { ArrowLeft, AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="pt-16 min-h-screen flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <AlertCircle className="w-12 h-12 text-[#737373] mx-auto mb-4" />
        <h1 className="text-4xl font-mono font-medium text-[#f5f5f5] mb-2">
          404
        </h1>
        <p className="text-sm text-[#737373] mb-6">
          This page doesn't exist in the command center.
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-6 py-3 bg-[#9eff00] text-[#050505] rounded-lg font-medium text-sm hover:bg-[#b3ff33] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>
      </motion.div>
    </div>
  );
}
