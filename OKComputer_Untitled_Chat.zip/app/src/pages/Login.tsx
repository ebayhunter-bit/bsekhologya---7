import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router";
import { useEffect, useMemo } from "react";
import { motion } from "framer-motion";
import { Brain, Zap, Shield } from "lucide-react";

function getOAuthUrl() {
  const authUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${authUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const loginUrl = useMemo(() => getOAuthUrl(), []);

  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  return (
    <div className="pt-16 min-h-screen flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-sm w-full"
      >
        <div className="command-card p-8 text-center">
          <div className="w-16 h-16 rounded-2xl bg-[#9eff00]/10 flex items-center justify-center mx-auto mb-6">
            <Brain className="w-8 h-8 text-[#9eff00]" />
          </div>

          <h1 className="text-2xl font-[Space_Grotesk] text-[#f5f5f5] mb-2">
            Welcome Back
          </h1>
          <p className="text-xs text-[#737373] mb-8">
            Sign in to track your progress and access personalized coaching.
          </p>

          <a
            href={loginUrl}
            className="w-full inline-flex items-center justify-center gap-2 py-3 bg-[#9eff00] text-[#050505] rounded-lg font-medium text-sm hover:bg-[#b3ff33] transition-colors"
          >
            <Zap className="w-4 h-4" />
            Sign In with Kimi
          </a>

          <div className="flex items-center justify-center gap-2 mt-6 text-[10px] text-[#737373]">
            <Shield className="w-3 h-3" />
            <span>Secure authentication</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
