import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate, useParams } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { motion, AnimatePresence } from "framer-motion";
import {
  Clock,
  ChevronLeft,
  ChevronRight,
  Pause,
  Play,
  RotateCcw,
  Flag,
  Check,
  X,
  AlertCircle,
  Brain,
  Target,
  Timer,
} from "lucide-react";

type TestPhase = "setup" | "countdown" | "testing" | "paused" | "review";

export default function MockTest() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { sessionId } = useParams();

  const [phase, setPhase] = useState<TestPhase>("setup");
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answers, setAnswers] = useState<
    Record<number, { selected: number; time: number; flagged: boolean }>
  >({});
  const [timeLeft, setTimeLeft] = useState(30 * 60); // 30 minutes
  const [questionStartTime, setQuestionStartTime] = useState(Date.now());
  const [showExplanation, setShowExplanation] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [explanation, setExplanation] = useState("");
  const [correctAnswer, setCorrectAnswer] = useState(0);
  const [activeSessionId, setActiveSessionId] = useState<number | null>(
    sessionId ? parseInt(sessionId) : null
  );
  const [countdown, setCountdown] = useState(3);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<number | undefined>();
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("adaptive");
  const [questionCount, setQuestionCount] = useState(10);

  // Fetch categories
  const { data: categories } = trpc.question.categories.useQuery();

  // Fetch questions
  const { data: questionList, refetch: refetchQuestions } =
    trpc.question.list.useQuery(
      {
        categoryId: selectedCategory,
        difficulty: selectedDifficulty as "easy" | "medium" | "hard" | undefined,
        limit: questionCount,
      },
      { enabled: false }
    );

  // Create session mutation
  const createSession = trpc.session.create.useMutation();
  const submitAnswer = trpc.session.submitAnswer.useMutation();
  const completeSession = trpc.session.complete.useMutation();

  // Timer logic
  useEffect(() => {
    if (phase === "testing") {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            setPhase("review");
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [phase]);

  // Countdown logic
  useEffect(() => {
    if (phase === "countdown") {
      const interval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setPhase("testing");
            setQuestionStartTime(Date.now());
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [phase]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  const startTest = useCallback(async () => {
    if (!user) {
      navigate("/login");
      return;
    }

    const { data: questions } = await refetchQuestions();
    if (!questions || questions.length === 0) {
      alert("No questions available. Please try again.");
      return;
    }

    const questionIds = questions.map((q) => q.id);
    const result = await createSession.mutateAsync({
      title: `Mock Test - ${new Date().toLocaleDateString()}`,
      categoryFilter: selectedCategory
        ? categories?.find((c) => c.id === selectedCategory)?.name
        : "Mixed",
      difficultyMode: selectedDifficulty as any,
      totalQuestions: questionCount,
      timeLimitMinutes: Math.ceil(questionCount * 1.5),
      questionIds,
    });

    setActiveSessionId(result.sessionId);
    setTimeLeft(Math.ceil(questionCount * 1.5) * 60);
    setAnswers({});
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setCountdown(3);
    setPhase("countdown");
  }, [user, selectedCategory, selectedDifficulty, questionCount, categories]);

  const handleSelectAnswer = (index: number) => {
    if (phase !== "testing" || selectedAnswer === null) return;
    setSelectedAnswer(index);
  };

  const handleConfirm = async () => {
    if (selectedAnswer === null || !questionList || !activeSessionId) return;

    const question = questionList[currentQuestion];
    const timeTaken = Math.round((Date.now() - questionStartTime) / 1000);

    const result = await submitAnswer.mutateAsync({
      sessionId: activeSessionId,
      questionId: question.id,
      selectedAnswer,
      timeTakenSeconds: timeTaken,
    });

    setIsCorrect(result.isCorrect);
    setCorrectAnswer(result.correctAnswer);
    setExplanation(result.explanation);
    setShowExplanation(true);

    setAnswers((prev) => ({
      ...prev,
      [currentQuestion]: {
        selected: selectedAnswer,
        time: timeTaken,
        flagged: prev[currentQuestion]?.flagged || false,
      },
    }));
  };

  const handleNext = () => {
    setShowExplanation(false);
    setSelectedAnswer(null);
    setIsCorrect(null);

    if (currentQuestion < (questionList?.length || 0) - 1) {
      setCurrentQuestion((prev) => prev + 1);
      setQuestionStartTime(Date.now());
    } else {
      // End of test
      if (activeSessionId) {
        completeSession.mutate(
          { sessionId: activeSessionId },
          {
            onSuccess: () => {
              setPhase("review");
            },
          }
        );
      }
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion((prev) => prev - 1);
      const prevAnswer = answers[currentQuestion - 1];
      setSelectedAnswer(prevAnswer?.selected ?? null);
      setShowExplanation(false);
    }
  };

  const toggleFlag = () => {
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion]: {
        selected: prev[currentQuestion]?.selected ?? -1,
        time: prev[currentQuestion]?.time ?? 0,
        flagged: !(prev[currentQuestion]?.flagged ?? false),
      },
    }));
  };

  const finishTest = () => {
    if (activeSessionId) {
      completeSession.mutate(
        { sessionId: activeSessionId },
        {
          onSuccess: () => {
            navigate(`/results/${activeSessionId}`);
          },
        }
      );
    }
  };

  // Setup Phase
  if (phase === "setup") {
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-lg w-full"
        >
          <div className="command-card p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-[#9eff00]/10 flex items-center justify-center">
                <Brain className="w-6 h-6 text-[#9eff00]" />
              </div>
              <div>
                <h2 className="text-xl font-[Space_Grotesk] text-[#f5f5f5]">
                  Mock Test Setup
                </h2>
                <p className="text-xs text-[#737373]">
                  Configure your test parameters
                </p>
              </div>
            </div>

            {/* Category Selection */}
            <div className="mb-5">
              <label className="text-label block mb-2">Category</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setSelectedCategory(undefined)}
                  className={`p-3 rounded-lg border text-xs font-medium transition-all ${
                    !selectedCategory
                      ? "border-[#9eff00]/50 bg-[#9eff00]/10 text-[#9eff00]"
                      : "border-[rgba(255,255,255,0.1)] bg-[#121212] text-[#737373] hover:text-[#f5f5f5]"
                  }`}
                >
                  <Target className="w-4 h-4 mx-auto mb-1" />
                  Mixed
                </button>
                {categories?.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`p-3 rounded-lg border text-xs font-medium transition-all ${
                      selectedCategory === cat.id
                        ? "border-[#9eff00]/50 bg-[#9eff00]/10 text-[#9eff00]"
                        : "border-[rgba(255,255,255,0.1)] bg-[#121212] text-[#737373] hover:text-[#f5f5f5]"
                    }`}
                  >
                    <Brain className="w-4 h-4 mx-auto mb-1" />
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Difficulty */}
            <div className="mb-5">
              <label className="text-label block mb-2">Difficulty</label>
              <div className="grid grid-cols-4 gap-2">
                {["adaptive", "easy", "medium", "hard"].map((d) => (
                  <button
                    key={d}
                    onClick={() => setSelectedDifficulty(d)}
                    className={`py-2 px-3 rounded-lg border text-xs font-medium capitalize transition-all ${
                      selectedDifficulty === d
                        ? "border-[#9eff00]/50 bg-[#9eff00]/10 text-[#9eff00]"
                        : "border-[rgba(255,255,255,0.1)] bg-[#121212] text-[#737373] hover:text-[#f5f5f5]"
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            {/* Question Count */}
            <div className="mb-6">
              <label className="text-label block mb-2">
                Questions: {questionCount}
              </label>
              <input
                type="range"
                min={5}
                max={25}
                step={5}
                value={questionCount}
                onChange={(e) => setQuestionCount(Number(e.target.value))}
                className="w-full accent-[#9eff00]"
              />
              <div className="flex justify-between text-[10px] text-[#737373] font-mono mt-1">
                <span>5</span>
                <span>10</span>
                <span>15</span>
                <span>20</span>
                <span>25</span>
              </div>
            </div>

            <button
              onClick={startTest}
              disabled={createSession.isPending}
              className="w-full py-3 bg-[#9eff00] text-[#050505] rounded-lg font-medium text-sm hover:bg-[#b3ff33] transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {createSession.isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-[#050505] border-t-transparent rounded-full animate-spin" />
                  Loading...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Start Test
                </>
              )}
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  // Countdown Phase
  if (phase === "countdown") {
    return (
      <div className="fixed inset-0 bg-[#050505] flex items-center justify-center z-50">
        <motion.div
          key={countdown}
          initial={{ scale: 2, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.5, opacity: 0 }}
          className="text-center"
        >
          <div className="text-[120px] font-mono font-medium text-[#9eff00] leading-none">
            {countdown}
          </div>
          <p className="text-sm text-[#737373] mt-4">
            Get ready...
          </p>
        </motion.div>
      </div>
    );
  }

  // Testing Phase
  const question = questionList?.[currentQuestion];
  const totalQuestions = questionList?.length || 0;
  void Object.keys(answers).length; // used for potential future UI
  const isPaused = phase === "paused";

  if (!question) return null;

  return (
    <div className="fixed inset-0 bg-[#050505] z-40 flex flex-col">
      {/* Header Bar */}
      <div className="h-14 border-b border-[rgba(255,255,255,0.06)] flex items-center justify-between px-4 bg-[#0a0a0a]">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setPhase(isPaused ? "testing" : "paused")}
            className="p-2 rounded-lg text-[#737373] hover:text-[#f5f5f5] hover:bg-[rgba(255,255,255,0.05)] transition-colors"
          >
            {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
          </button>
          <div className="text-xs font-mono text-[#737373]">
            {currentQuestion + 1} / {totalQuestions}
          </div>
        </div>

        {/* Timer */}
        <div
          className={`flex items-center gap-2 px-4 py-1.5 rounded-full ${
            timeLeft < 60
              ? "bg-[#ef4444]/10 text-[#ef4444]"
              : timeLeft < 300
                ? "bg-[#f97316]/10 text-[#f97316]"
                : "bg-[#121212] text-[#f5f5f5]"
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span className="font-mono text-sm font-medium">
            {formatTime(timeLeft)}
          </span>
        </div>

        <button
          onClick={toggleFlag}
          className={`p-2 rounded-lg transition-colors ${
            answers[currentQuestion]?.flagged
              ? "text-[#f97316] bg-[#f97316]/10"
              : "text-[#737373] hover:text-[#f5f5f5] hover:bg-[rgba(255,255,255,0.05)]"
          }`}
        >
          <Flag className="w-4 h-4" />
        </button>
      </div>

      {/* Progress Bar */}
      <div className="h-1 bg-[rgba(255,255,255,0.05)]">
        <div
          className="h-full bg-[#9eff00] transition-all duration-300"
          style={{ width: `${((currentQuestion + 1) / totalQuestions) * 100}%` }}
        />
      </div>

      {/* Question Segments */}
      <div className="flex gap-1 px-4 py-2 overflow-x-auto scrollbar-hide">
        {Array.from({ length: totalQuestions }).map((_, i) => {
          const ans = answers[i];
          const isCurrent = i === currentQuestion;
          return (
            <button
              key={i}
              onClick={() => {
                if (!showExplanation) {
                  setCurrentQuestion(i);
                  setSelectedAnswer(ans?.selected ?? null);
                  setQuestionStartTime(Date.now());
                }
              }}
              className={`w-6 h-6 rounded text-[10px] font-mono flex-shrink-0 transition-all ${
                isCurrent
                  ? "bg-[#9eff00] text-[#050505]"
                  : ans
                    ? ans.selected === (questionList?.[i]?.correctAnswer ?? -1)
                      ? "bg-[#9eff00]/20 text-[#9eff00] border border-[#9eff00]/30"
                      : "bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/30"
                    : "bg-[#121212] text-[#737373] border border-[rgba(255,255,255,0.05)]"
              } ${ans?.flagged ? "ring-1 ring-[#f97316]" : ""}`}
            >
              {i + 1}
            </button>
          );
        })}
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto px-4 py-6">
        <AnimatePresence mode="wait">
          {isPaused ? (
            <motion.div
              key="paused"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-2xl mx-auto text-center py-20"
            >
              <Pause className="w-12 h-12 text-[#737373] mx-auto mb-4" />
              <h3 className="text-2xl font-[Space_Grotesk] text-[#f5f5f5] mb-2">
                Test Paused
              </h3>
              <p className="text-sm text-[#737373] mb-8">
                Take a breather. Your progress is saved.
              </p>
              <div className="flex items-center justify-center gap-3">
                <button
                  onClick={() => setPhase("testing")}
                  className="flex items-center gap-2 px-6 py-3 bg-[#9eff00] text-[#050505] rounded-lg font-medium text-sm hover:bg-[#b3ff33] transition-colors"
                >
                  <Play className="w-4 h-4" />
                  Resume
                </button>
                <button
                  onClick={finishTest}
                  className="flex items-center gap-2 px-6 py-3 bg-[#ef4444]/10 text-[#ef4444] rounded-lg font-medium text-sm hover:bg-[#ef4444]/20 transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  End Test
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key={`q-${currentQuestion}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="max-w-2xl mx-auto"
            >
              {/* Question */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-4">
                  <span className="px-2 py-0.5 rounded bg-[#a855f7]/10 text-[#a855f7] text-[10px] font-mono uppercase">
                    {question.type.replace("_", " ")}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase ${
                      question.difficulty === "easy"
                        ? "bg-[#9eff00]/10 text-[#9eff00]"
                        : question.difficulty === "medium"
                          ? "bg-[#f97316]/10 text-[#f97316]"
                          : "bg-[#ef4444]/10 text-[#ef4444]"
                    }`}
                  >
                    {question.difficulty}
                  </span>
                  <span className="text-[10px] text-[#737373] font-mono flex items-center gap-1">
                    <Timer className="w-3 h-3" />
                    {question.timeLimitSeconds}s
                  </span>
                </div>
                <h3 className="text-xl font-[Space_Grotesk] text-[#f5f5f5] leading-relaxed">
                  {question.questionText}
                </h3>
              </div>

              {/* Options */}
              <div className="space-y-3 mb-8">
                {question.options.map((option, i) => {
                  let state: "default" | "selected" | "correct" | "incorrect" =
                    "default";
                  if (showExplanation) {
                    if (i === correctAnswer) state = "correct";
                    else if (i === selectedAnswer) state = "incorrect";
                  } else if (i === selectedAnswer) {
                    state = "selected";
                  }

                  return (
                    <button
                      key={i}
                      onClick={() => handleSelectAnswer(i)}
                      disabled={showExplanation}
                      className={`w-full p-4 rounded-xl border text-left transition-all ${
                        state === "default"
                          ? "border-[rgba(255,255,255,0.1)] bg-[#0a0a0a] hover:border-[rgba(255,255,255,0.2)] hover:bg-[#121212]"
                          : state === "selected"
                            ? "border-[#9eff00]/50 bg-[#9eff00]/10"
                            : state === "correct"
                              ? "border-[#9eff00] bg-[#9eff00]/20"
                              : "border-[#ef4444] bg-[#ef4444]/10"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-6 h-6 rounded-full border flex items-center justify-center text-xs font-mono flex-shrink-0 ${
                            state === "default"
                              ? "border-[rgba(255,255,255,0.2)] text-[#737373]"
                              : state === "selected"
                                ? "border-[#9eff00] text-[#9eff00]"
                                : state === "correct"
                                  ? "border-[#9eff00] bg-[#9eff00] text-[#050505]"
                                  : "border-[#ef4444] bg-[#ef4444] text-white"
                          }`}
                        >
                          {state === "correct" ? (
                            <Check className="w-3 h-3" />
                          ) : state === "incorrect" ? (
                            <X className="w-3 h-3" />
                          ) : (
                            String.fromCharCode(65 + i)
                          )}
                        </div>
                        <span
                          className={`text-sm ${
                            state === "incorrect"
                              ? "text-[#ef4444]"
                              : state === "correct"
                                ? "text-[#9eff00]"
                                : "text-[#f5f5f5]"
                          }`}
                        >
                          {option}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Explanation Panel */}
              <AnimatePresence>
                {showExplanation && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mb-6"
                  >
                    <div
                      className={`p-4 rounded-xl border ${
                        isCorrect
                          ? "border-[#9eff00]/30 bg-[#9eff00]/5"
                          : "border-[#ef4444]/30 bg-[#ef4444]/5"
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        {isCorrect ? (
                          <Check className="w-4 h-4 text-[#9eff00]" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-[#ef4444]" />
                        )}
                        <span
                          className={`text-sm font-medium ${
                            isCorrect ? "text-[#9eff00]" : "text-[#ef4444]"
                          }`}
                        >
                          {isCorrect ? "Correct!" : "Incorrect"}
                        </span>
                      </div>
                      <p className="text-sm text-[#737373] leading-relaxed">
                        {explanation}
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Action Buttons */}
              <div className="flex items-center justify-between">
                <button
                  onClick={handlePrevious}
                  disabled={currentQuestion === 0}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[rgba(255,255,255,0.1)] text-sm text-[#737373] hover:text-[#f5f5f5] hover:border-[rgba(255,255,255,0.2)] disabled:opacity-30 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </button>

                {!showExplanation ? (
                  <button
                    onClick={handleConfirm}
                    disabled={selectedAnswer === null}
                    className="flex items-center gap-2 px-6 py-2.5 bg-[#9eff00] text-[#050505] rounded-lg font-medium text-sm hover:bg-[#b3ff33] disabled:opacity-30 transition-colors"
                  >
                    Confirm
                    <Check className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    onClick={handleNext}
                    className="flex items-center gap-2 px-6 py-2.5 bg-[#9eff00] text-[#050505] rounded-lg font-medium text-sm hover:bg-[#b3ff33] transition-colors"
                  >
                    {currentQuestion < totalQuestions - 1 ? (
                      <>
                        Next
                        <ChevronRight className="w-4 h-4" />
                      </>
                    ) : (
                      <>
                        Finish
                        <Check className="w-4 h-4" />
                      </>
                    )}
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
