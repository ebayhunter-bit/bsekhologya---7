import { useState, useRef, useEffect } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send,
  Brain,
  ArrowLeft,
  Lock,
  User,
  Sparkles,
  Trash2,
  Loader2,
  BookOpen,
  Target,
  Lightbulb,
  MessageSquare,
} from "lucide-react";

type Message = {
  id: number;
  role: "user" | "assistant";
  content: string;
  createdAt: Date;
};

const QUICK_PROMPTS = [
  {
    icon: <BookOpen className="w-4 h-4" />,
    label: "Number Sequences",
    prompt: "How do I solve number sequence problems? What's the best strategy?",
  },
  {
    icon: <Target className="w-4 h-4" />,
    label: "Percentages",
    prompt: "Explain how to calculate percentage increase and decrease quickly.",
  },
  {
    icon: <Lightbulb className="w-4 h-4" />,
    label: "Abstract Patterns",
    prompt: "What are the most common transformation rules in abstract reasoning?",
  },
  {
    icon: <MessageSquare className="w-4 h-4" />,
    label: "Syllogisms",
    prompt: "How do I approach syllogism questions? What's the foolproof method?",
  },
];

export default function Tutor() {
  const { user } = useAuth();
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: history, isLoading } = trpc.tutor.history.useQuery(
    { limit: 50 },
    { enabled: !!user }
  );
  const askMutation = trpc.tutor.ask.useMutation();
  const clearMutation = trpc.tutor.clear.useMutation();
  const utils = trpc.useUtils();

  // Load history
  useEffect(() => {
    if (history) {
      setMessages(
        [...history]
          .reverse()
          .map((m) => ({
            id: m.id,
            role: m.role as "user" | "assistant",
            content: m.content,
            createdAt: m.createdAt,
          }))
      );
    }
  }, [history]);

  // Auto scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (text: string) => {
    if (!text.trim() || askMutation.isPending) return;

    const tempId = Date.now();
    const userMsg: Message = {
      id: tempId,
      role: "user",
      content: text,
      createdAt: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");

    try {
      const result = await askMutation.mutateAsync({
        message: text,
        contextType: "general",
      });

      const assistantMsg: Message = {
        id: tempId + 1,
        role: "assistant",
        content: result.response,
        createdAt: new Date(),
      };

      setMessages((prev) => [...prev, assistantMsg]);
      utils.tutor.history.invalidate();
    } catch {
      const errorMsg: Message = {
        id: tempId + 1,
        role: "assistant",
        content:
          "I'm sorry, I encountered an error. Please try again.",
        createdAt: new Date(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    }
  };

  const handleClear = () => {
    clearMutation.mutate(undefined, {
      onSuccess: () => {
        setMessages([]);
        utils.tutor.history.invalidate();
      },
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSend(input);
  };

  if (!user) {
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Lock className="w-10 h-10 text-[#737373] mx-auto mb-3" />
          <p className="text-sm text-[#737373]">
            Sign in to chat with Dr. Sigma
          </p>
          <Link
            to="/login"
            className="inline-flex items-center gap-2 mt-3 px-4 py-2 bg-[#9eff00] text-[#050505] rounded-lg text-xs font-medium"
          >
            Sign In
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-16 h-[calc(100vh-64px)] flex flex-col">
      {/* Header */}
      <div className="border-b border-[rgba(255,255,255,0.06)] px-4 py-3 bg-[#0a0a0a]">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link
              to="/"
              className="p-1.5 rounded-lg text-[#737373] hover:text-[#f5f5f5] hover:bg-[rgba(255,255,255,0.05)] transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-[#9eff00]/10 flex items-center justify-center">
                <Brain className="w-4 h-4 text-[#9eff00]" />
              </div>
              <div>
                <h2 className="text-sm font-medium text-[#f5f5f5]">
                  Dr. Sigma
                </h2>
                <p className="text-[10px] text-[#737373]">
                  AI Psychometric Coach
                </p>
              </div>
            </div>
          </div>
          <button
            onClick={handleClear}
            className="p-2 rounded-lg text-[#737373] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors"
            title="Clear chat"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto px-4 py-6">
        <div className="max-w-3xl mx-auto space-y-6">
          {messages.length === 0 && !isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <div className="w-16 h-16 rounded-2xl bg-[#9eff00]/10 flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-[#9eff00]" />
              </div>
              <h3 className="text-lg font-[Space_Grotesk] text-[#f5f5f5] mb-2">
                Ask Dr. Sigma Anything
              </h3>
              <p className="text-xs text-[#737373] mb-8 max-w-sm mx-auto">
                Your personal psychometric reasoning coach. Ask about strategies, specific concepts, or get help with tricky problems.
              </p>

              {/* Quick Prompts */}
              <div className="grid grid-cols-2 gap-2 max-w-md mx-auto">
                {QUICK_PROMPTS.map((prompt) => (
                  <button
                    key={prompt.label}
                    onClick={() => handleSend(prompt.prompt)}
                    className="flex items-center gap-2 p-3 rounded-lg bg-[#0a0a0a] border border-[rgba(255,255,255,0.08)] hover:border-[#9eff00]/30 hover:bg-[#9eff00]/5 transition-all text-left"
                  >
                    <span className="text-[#9eff00]">{prompt.icon}</span>
                    <span className="text-xs text-[#f5f5f5]">
                      {prompt.label}
                    </span>
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          <AnimatePresence>
            {messages.map((msg, index) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index === messages.length - 1 ? 0 : 0 }}
                className={`flex gap-3 ${
                  msg.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                {msg.role === "assistant" && (
                  <div className="w-7 h-7 rounded-lg bg-[#9eff00]/10 flex items-center justify-center flex-shrink-0 mt-1">
                    <Brain className="w-3.5 h-3.5 text-[#9eff00]" />
                  </div>
                )}

                <div
                  className={`max-w-[80%] p-4 rounded-xl ${
                    msg.role === "user"
                      ? "bg-[#9eff00]/10 border border-[#9eff00]/20"
                      : "bg-[#121212] border border-[rgba(255,255,255,0.06)]"
                  }`}
                >
                  <div className="text-xs text-[#f5f5f5] whitespace-pre-wrap leading-relaxed">
                    {msg.content}
                  </div>
                </div>

                {msg.role === "user" && (
                  <div className="w-7 h-7 rounded-lg bg-[#a855f7]/10 flex items-center justify-center flex-shrink-0 mt-1">
                    <User className="w-3.5 h-3.5 text-[#a855f7]" />
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>

          {askMutation.isPending && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-3"
            >
              <div className="w-7 h-7 rounded-lg bg-[#9eff00]/10 flex items-center justify-center flex-shrink-0">
                <Brain className="w-3.5 h-3.5 text-[#9eff00]" />
              </div>
              <div className="p-4 rounded-xl bg-[#121212] border border-[rgba(255,255,255,0.06)]">
                <Loader2 className="w-4 h-4 text-[#737373] animate-spin" />
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="border-t border-[rgba(255,255,255,0.06)] px-4 py-4 bg-[#0a0a0a]">
        <form
          onSubmit={handleSubmit}
          className="max-w-3xl mx-auto flex items-center gap-3"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about sequences, percentages, patterns..."
            className="flex-1 bg-[#121212] border border-[rgba(255,255,255,0.1)] rounded-lg px-4 py-3 text-xs text-[#f5f5f5] placeholder:text-[#404040] focus:outline-none focus:border-[#9eff00]/50 transition-colors"
          />
          <button
            type="submit"
            disabled={!input.trim() || askMutation.isPending}
            className="p-3 bg-[#9eff00] text-[#050505] rounded-lg hover:bg-[#b3ff33] disabled:opacity-30 disabled:hover:bg-[#9eff00] transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
