import { useEffect, useState } from "react";
import { Link } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import {
  Brain,
  Target,
  TrendingUp,
  Clock,
  Award,
  Calendar,
  Play,
  ChevronRight,
  Zap,
  BarChart3,
  BookOpen,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts";

export default function Dashboard() {
  const { user } = useAuth();
  const [seeded, setSeeded] = useState(false);

  // Seed data on first load
  const seedMutation = trpc.seed.run.useMutation();

  useEffect(() => {
    if (!seeded) {
      seedMutation.mutate(undefined, {
        onSuccess: () => setSeeded(true),
        onError: () => setSeeded(true),
      });
    }
  }, [seeded]);

  // Fetch analytics
  const { data: summary } = trpc.analytics.summary.useQuery(undefined, {
    enabled: !!user,
  });
  const { data: planProgress } = trpc.studyPlan.progress.useQuery(undefined, {
    enabled: !!user,
  });
  const { data: recentSessions } = trpc.session.recent.useQuery(
    { limit: 5 },
    { enabled: !!user }
  );
  const { data: dailyActivity } = trpc.analytics.dailyActivity.useQuery(
    { days: 30 },
    { enabled: !!user }
  );

  // Calculate mastery percentage
  const masteryPercent = summary?.avgScore || 0;
  const circumference = 2 * Math.PI * 70;
  const strokeDashoffset =
    circumference - (masteryPercent / 100) * circumference;

  return (
    <div className="pt-16 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-3xl font-[Space_Grotesk] font-medium text-[#f5f5f5]">
              {user?.name
                ? `Welcome back, ${user.name.split(" ")[0]}`
                : "Command Center"}
            </h1>
            <span className="px-2 py-0.5 rounded-full bg-[#9eff00]/10 border border-[#9eff00]/30 text-[10px] font-mono text-[#9eff00] uppercase tracking-wider">
              Day {planProgress?.currentDay || 1} / 30
            </span>
          </div>
          <p className="text-sm text-[#737373]">
            Your 30-day psychometric mastery journey. {planProgress?.daysLeft || 30} days to exam readiness.
          </p>
        </motion.div>

        {!user && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mb-8 p-6 rounded-xl bg-[#0a0a0a] border border-[rgba(255,255,255,0.1)] text-center"
          >
            <Brain className="w-10 h-10 text-[#9eff00] mx-auto mb-3" />
            <h2 className="text-xl font-[Space_Grotesk] text-[#f5f5f5] mb-2">
              Start Your 30-Day Transformation
            </h2>
            <p className="text-sm text-[#737373] mb-4 max-w-md mx-auto">
              Sign in to track your progress, take adaptive mock tests, and get AI-powered coaching.
            </p>
            <Link
              to="/login"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#9eff00] text-[#050505] rounded-lg font-medium text-sm hover:bg-[#b3ff33] transition-colors"
            >
              <Zap className="w-4 h-4" />
              Get Started
            </Link>
          </motion.div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - 2/3 width */}
          <div className="lg:col-span-2 space-y-6">
            {/* Mastery Radial Chart */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="command-card p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <span className="text-label">Progress to Mastery</span>
                  <h3 className="text-lg font-[Space_Grotesk] text-[#f5f5f5] mt-1">
                    Overall Performance
                  </h3>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-2xl font-mono font-medium text-[#9eff00]">
                      {summary?.avgScore || 0}%
                    </div>
                    <div className="text-[10px] text-[#737373] font-mono uppercase">
                      Avg Score
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-8">
                {/* Radial Chart */}
                <div className="relative w-40 h-40 flex-shrink-0">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
                    <circle
                      cx="80"
                      cy="80"
                      r="70"
                      fill="none"
                      stroke="rgba(255,255,255,0.05)"
                      strokeWidth="10"
                    />
                    <circle
                      cx="80"
                      cy="80"
                      r="70"
                      fill="none"
                      stroke="#9eff00"
                      strokeWidth="10"
                      strokeLinecap="round"
                      strokeDasharray={circumference}
                      strokeDashoffset={strokeDashoffset}
                      className="transition-all duration-1000"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-3xl font-mono font-medium text-[#f5f5f5]">
                        {summary?.totalTests || 0}
                      </div>
                      <div className="text-[10px] text-[#737373] font-mono uppercase">
                        Tests
                      </div>
                    </div>
                  </div>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-4 flex-1">
                  <StatBox
                    icon={<Target className="w-4 h-4" />}
                    label="Best Score"
                    value={`${summary?.bestScore || 0}%`}
                    color="#9eff00"
                  />
                  <StatBox
                    icon={<BookOpen className="w-4 h-4" />}
                    label="Questions"
                    value={String(summary?.totalQuestionsAnswered || 0)}
                    color="#a855f7"
                  />
                  <StatBox
                    icon={<Award className="w-4 h-4" />}
                    label="Current Streak"
                    value={`${summary?.currentStreak || 0}d`}
                    color="#f97316"
                  />
                  <StatBox
                    icon={<TrendingUp className="w-4 h-4" />}
                    label="Completion"
                    value={`${planProgress?.completionRate || 0}%`}
                    color="#3b82f6"
                  />
                </div>
              </div>
            </motion.div>

            {/* Score Trend Chart */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="command-card p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <span className="text-label">Score History</span>
                  <h3 className="text-lg font-[Space_Grotesk] text-[#f5f5f5] mt-1">
                    Performance Trend
                  </h3>
                </div>
              </div>
              <div className="h-48">
                {summary?.scoreTrend && summary.scoreTrend.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={summary.scoreTrend}>
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="rgba(255,255,255,0.05)"
                      />
                      <XAxis
                        dataKey="session"
                        stroke="#404040"
                        tick={{ fontSize: 11, fontFamily: "JetBrains Mono" }}
                      />
                      <YAxis
                        domain={[0, 100]}
                        stroke="#404040"
                        tick={{ fontSize: 11, fontFamily: "JetBrains Mono" }}
                      />
                      <Tooltip
                        contentStyle={{
                          background: "#1a1a1a",
                          border: "1px solid rgba(255,255,255,0.1)",
                          borderRadius: "8px",
                          fontSize: "12px",
                        }}
                        labelStyle={{ color: "#737373" }}
                      />
                      <Line
                        type="monotone"
                        dataKey="score"
                        stroke="#9eff00"
                        strokeWidth={2}
                        dot={{ fill: "#9eff00", r: 3 }}
                        activeDot={{ r: 5 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-sm text-[#737373]">
                    Complete a mock test to see your score trend
                  </div>
                )}
              </div>
            </motion.div>

            {/* Recent Sessions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="command-card p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <span className="text-label">Recent Activity</span>
                  <h3 className="text-lg font-[Space_Grotesk] text-[#f5f5f5] mt-1">
                    Mock Test History
                  </h3>
                </div>
                <Link
                  to="/test"
                  className="flex items-center gap-1 text-xs text-[#9eff00] hover:underline"
                >
                  New Test
                  <ChevronRight className="w-3 h-3" />
                </Link>
              </div>

              {recentSessions && recentSessions.length > 0 ? (
                <div className="space-y-3">
                  {recentSessions.map((session) => (
                    <div
                      key={session.id}
                      className="flex items-center justify-between p-3 rounded-lg bg-[#121212] border border-[rgba(255,255,255,0.05)]"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                            (session.score || 0) >= 70
                              ? "bg-[#9eff00]/10"
                              : "bg-[#ef4444]/10"
                          }`}
                        >
                          <Brain
                            className={`w-4 h-4 ${
                              (session.score || 0) >= 70
                                ? "text-[#9eff00]"
                                : "text-[#ef4444]"
                            }`}
                          />
                        </div>
                        <div>
                          <div className="text-sm text-[#f5f5f5]">
                            {session.title}
                          </div>
                          <div className="text-[10px] text-[#737373] font-mono">
                            {session.questionsAnswered || 0}/{session.totalQuestions} questions
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div
                          className={`text-sm font-mono font-medium ${
                            (session.score || 0) >= 70
                              ? "text-[#9eff00]"
                              : "text-[#ef4444]"
                          }`}
                        >
                          {session.score || 0}%
                        </div>
                        <div className="text-[10px] text-[#737373] font-mono">
                          {session.startedAt
                            ? new Date(session.startedAt).toLocaleDateString()
                            : ""}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Clock className="w-8 h-8 text-[#404040] mx-auto mb-2" />
                  <p className="text-sm text-[#737373]">
                    No tests taken yet. Start your first mock test!
                  </p>
                  <Link
                    to="/test"
                    className="inline-flex items-center gap-2 mt-3 px-4 py-2 bg-[#9eff00] text-[#050505] rounded-lg text-xs font-medium hover:bg-[#b3ff33] transition-colors"
                  >
                    <Play className="w-3 h-3" />
                    Start Mock Test
                  </Link>
                </div>
              )}
            </motion.div>
          </div>

          {/* Right Column - 1/3 width */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.15 }}
              className="command-card p-5"
            >
              <span className="text-label">Quick Actions</span>
              <div className="mt-4 space-y-2">
                <Link
                  to="/test"
                  className="flex items-center gap-3 p-3 rounded-lg bg-[#9eff00]/10 border border-[#9eff00]/20 hover:border-[#9eff00]/40 transition-colors group"
                >
                  <Brain className="w-5 h-5 text-[#9eff00]" />
                  <div>
                    <div className="text-sm font-medium text-[#f5f5f5] group-hover:text-[#9eff00] transition-colors">
                      Start Mock Test
                    </div>
                    <div className="text-[10px] text-[#737373]">
                      Adaptive difficulty
                    </div>
                  </div>
                </Link>
                <Link
                  to="/study-plan"
                  className="flex items-center gap-3 p-3 rounded-lg bg-[#121212] border border-[rgba(255,255,255,0.05)] hover:border-[rgba(255,255,255,0.15)] transition-colors group"
                >
                  <Calendar className="w-5 h-5 text-[#a855f7]" />
                  <div>
                    <div className="text-sm font-medium text-[#f5f5f5]">
                      Study Plan
                    </div>
                    <div className="text-[10px] text-[#737373]">
                      Day {planProgress?.currentDay || 1} of 30
                    </div>
                  </div>
                </Link>
                <Link
                  to="/tutor"
                  className="flex items-center gap-3 p-3 rounded-lg bg-[#121212] border border-[rgba(255,255,255,0.05)] hover:border-[rgba(255,255,255,0.15)] transition-colors group"
                >
                  <MessageSquareCode className="w-5 h-5 text-[#f97316]" />
                  <div>
                    <div className="text-sm font-medium text-[#f5f5f5]">
                      AI Tutor
                    </div>
                    <div className="text-[10px] text-[#737373]">
                      Ask Dr. Sigma
                    </div>
                  </div>
                </Link>
              </div>
            </motion.div>

            {/* Category Mastery */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.25 }}
              className="command-card p-5"
            >
              <span className="text-label">Category Mastery</span>
              <div className="mt-4 h-48">
                {summary?.categoryProgress &&
                summary.categoryProgress.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={summary.categoryProgress}>
                      <PolarGrid stroke="rgba(255,255,255,0.1)" />
                      <PolarAngleAxis
                        dataKey="category"
                        tick={{ fontSize: 10, fill: "#737373" }}
                      />
                      <PolarRadiusAxis
                        angle={90}
                        domain={[0, 100]}
                        tick={{ fontSize: 9, fill: "#404040" }}
                      />
                      <Radar
                        name="Accuracy"
                        dataKey="accuracy"
                        stroke="#9eff00"
                        fill="#9eff00"
                        fillOpacity={0.2}
                        strokeWidth={2}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-xs text-[#737373]">
                    Take tests to see category breakdown
                  </div>
                )}
              </div>
            </motion.div>

            {/* Study Calendar Heatmap */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.35 }}
              className="command-card p-5"
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-label">Study Activity</span>
                <span className="text-[10px] text-[#737373] font-mono">
                  Last 30 days
                </span>
              </div>
              <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: 28 }).map((_, i) => {
                  const day = dailyActivity?.[i];
                  const intensity = day?.intensity || 0;
                  return (
                    <div
                      key={i}
                      className={`aspect-square rounded-sm ${
                        intensity === 0
                          ? "bg-[rgba(255,255,255,0.03)]"
                          : intensity === 1
                            ? "bg-[#9eff00]/20"
                            : intensity === 2
                              ? "bg-[#9eff00]/40"
                              : intensity === 3
                                ? "bg-[#9eff00]/60"
                                : "bg-[#9eff00]/80"
                      }`}
                      title={day ? `${day.date}: ${day.questions} questions` : ""}
                    />
                  );
                })}
              </div>
              <div className="flex items-center justify-between mt-2 text-[10px] text-[#737373]">
                <span>Less</span>
                <div className="flex gap-1">
                  <div className="w-2.5 h-2.5 rounded-sm bg-[rgba(255,255,255,0.03)]" />
                  <div className="w-2.5 h-2.5 rounded-sm bg-[#9eff00]/20" />
                  <div className="w-2.5 h-2.5 rounded-sm bg-[#9eff00]/40" />
                  <div className="w-2.5 h-2.5 rounded-sm bg-[#9eff00]/60" />
                  <div className="w-2.5 h-2.5 rounded-sm bg-[#9eff00]/80" />
                </div>
                <span>More</span>
              </div>
            </motion.div>

            {/* Weak Areas */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="command-card p-5"
            >
              <span className="text-label">Focus Areas</span>
              <div className="mt-4 space-y-3">
                {summary?.categoryProgress &&
                summary.categoryProgress.length > 0 ? (
                  summary.categoryProgress
                    .sort((a, b) => a.accuracy - b.accuracy)
                    .slice(0, 3)
                    .map((cat) => (
                      <div key={cat.categoryId}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-[#f5f5f5]">
                            {cat.category}
                          </span>
                          <span className="text-xs font-mono text-[#737373]">
                            {cat.accuracy}%
                          </span>
                        </div>
                        <div className="h-1.5 rounded-full bg-[rgba(255,255,255,0.05)] overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{
                              width: `${cat.accuracy}%`,
                              backgroundColor:
                                cat.accuracy >= 70
                                  ? "#9eff00"
                                  : cat.accuracy >= 50
                                    ? "#f97316"
                                    : "#ef4444",
                            }}
                          />
                        </div>
                      </div>
                    ))
                ) : (
                  <div className="text-center py-4">
                    <BarChart3 className="w-6 h-6 text-[#404040] mx-auto mb-1" />
                    <p className="text-xs text-[#737373]">
                      Practice to identify weak areas
                    </p>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatBox({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <div className="p-3 rounded-lg bg-[#121212] border border-[rgba(255,255,255,0.05)]">
      <div className="flex items-center gap-2 mb-1" style={{ color }}>
        {icon}
        <span className="text-[10px] font-mono uppercase tracking-wider text-[#737373]">
          {label}
        </span>
      </div>
      <div className="text-lg font-mono font-medium text-[#f5f5f5]">
        {value}
      </div>
    </div>
  );
}

function MessageSquareCode({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M7 9h10" />
      <path d="M7 13h4" />
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  );
}
