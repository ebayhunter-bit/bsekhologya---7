import { useParams, Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  RotateCcw,
  Check,
  X,
  Clock,
  AlertCircle,
  Brain,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

export default function TestResults() {
  const { sessionId } = useParams();
  const id = parseInt(sessionId || "0");

  const { data: results, isLoading } = trpc.session.results.useQuery(
    { sessionId: id },
    { enabled: id > 0 }
  );

  if (isLoading) {
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#9eff00] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!results) {
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-10 h-10 text-[#737373] mx-auto mb-3" />
          <p className="text-sm text-[#737373]">Test results not found</p>
          <Link
            to="/"
            className="inline-flex items-center gap-1 text-sm text-[#9eff00] mt-3 hover:underline"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  const correctCount = results.answers.filter((a) => a.isCorrect).length;
  const totalCount = results.answers.length;
  const score = results.score || 0;
  const avgTime =
    totalCount > 0
      ? Math.round((results.timeUsedSeconds || 0) / totalCount)
      : 0;

  // Time per question data for chart
  const timeData = results.answers.map((a, i) => ({
    question: i + 1,
    time: a.timeTakenSeconds,
    optimal: a.question?.timeLimitSeconds || 60,
    correct: a.isCorrect,
  }));

  // Category breakdown
  const categoryMap: Record<string, { correct: number; total: number }> = {};
  results.answers.forEach((a) => {
    const cat = a.question?.type || "Unknown";
    if (!categoryMap[cat]) categoryMap[cat] = { correct: 0, total: 0 };
    categoryMap[cat].total++;
    if (a.isCorrect) categoryMap[cat].correct++;
  });

  const categoryData = Object.entries(categoryMap).map(([cat, data]) => ({
    category: cat.replace("_", " "),
    accuracy: Math.round((data.correct / data.total) * 100),
    correct: data.correct,
    total: data.total,
  }));

  return (
    <div className="pt-16 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Link
            to="/"
            className="inline-flex items-center gap-1 text-xs text-[#737373] hover:text-[#f5f5f5] mb-4 transition-colors"
          >
            <ArrowLeft className="w-3 h-3" />
            Back to Dashboard
          </Link>
          <h1 className="text-3xl font-[Space_Grotesk] text-[#f5f5f5] mb-1">
            Test Results
          </h1>
          <p className="text-sm text-[#737373]">{results.title}</p>
        </motion.div>

        {/* Score Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="command-card p-8 mb-6 text-center"
        >
          <div className="relative inline-block mb-4">
            <svg className="w-32 h-32 -rotate-90" viewBox="0 0 128 128">
              <circle
                cx="64"
                cy="64"
                r="56"
                fill="none"
                stroke="rgba(255,255,255,0.05)"
                strokeWidth="10"
              />
              <circle
                cx="64"
                cy="64"
                r="56"
                fill="none"
                stroke={score >= 70 ? "#9eff00" : score >= 50 ? "#f97316" : "#ef4444"}
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 56}
                strokeDashoffset={
                  2 * Math.PI * 56 - (score / 100) * 2 * Math.PI * 56
                }
                className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-mono font-medium text-[#f5f5f5]">
                {score}%
              </span>
              <span className="text-[10px] text-[#737373] font-mono uppercase">
                Score
              </span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
            <div className="p-3 rounded-lg bg-[#121212]">
              <div className="flex items-center justify-center gap-1 text-[#9eff00] mb-1">
                <Check className="w-3 h-3" />
                <span className="text-lg font-mono">{correctCount}</span>
              </div>
              <span className="text-[10px] text-[#737373] font-mono uppercase">
                Correct
              </span>
            </div>
            <div className="p-3 rounded-lg bg-[#121212]">
              <div className="flex items-center justify-center gap-1 text-[#ef4444] mb-1">
                <X className="w-3 h-3" />
                <span className="text-lg font-mono">
                  {totalCount - correctCount}
                </span>
              </div>
              <span className="text-[10px] text-[#737373] font-mono uppercase">
                Incorrect
              </span>
            </div>
            <div className="p-3 rounded-lg bg-[#121212]">
              <div className="flex items-center justify-center gap-1 text-[#a855f7] mb-1">
                <Clock className="w-3 h-3" />
                <span className="text-lg font-mono">{avgTime}s</span>
              </div>
              <span className="text-[10px] text-[#737373] font-mono uppercase">
                Avg Time
              </span>
            </div>
          </div>
        </motion.div>

        {/* Time Analysis Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="command-card p-6 mb-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-label">Time Analysis</span>
              <h3 className="text-lg font-[Space_Grotesk] text-[#f5f5f5] mt-1">
                Speed vs. Optimal
              </h3>
            </div>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={timeData}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="rgba(255,255,255,0.05)"
                />
                <XAxis
                  dataKey="question"
                  stroke="#404040"
                  tick={{ fontSize: 10, fontFamily: "JetBrains Mono" }}
                  label={{
                    value: "Question",
                    position: "insideBottom",
                    offset: -2,
                    style: { fill: "#737373", fontSize: 10 },
                  }}
                />
                <YAxis
                  stroke="#404040"
                  tick={{ fontSize: 10, fontFamily: "JetBrains Mono" }}
                  label={{
                    value: "Seconds",
                    angle: -90,
                    position: "insideLeft",
                    style: { fill: "#737373", fontSize: 10 },
                  }}
                />
                <Tooltip
                  contentStyle={{
                    background: "#1a1a1a",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                    fontSize: "11px",
                  }}
                />
                <Bar dataKey="time" radius={[3, 3, 0, 0]}>
                  {timeData.map((entry, index) => (
                    <Cell
                      key={index}
                      fill={entry.correct ? "#9eff00" : "#ef4444"}
                      fillOpacity={0.6}
                    />
                  ))}
                </Bar>
                <Bar
                  dataKey="optimal"
                  fill="rgba(255,255,255,0.1)"
                  radius={[3, 3, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center gap-4 mt-3 text-[10px] text-[#737373]">
            <div className="flex items-center gap-1">
              <div className="w-2.5 h-2.5 rounded-sm bg-[#9eff00]/60" />
              <span>Your time (correct)</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2.5 h-2.5 rounded-sm bg-[#ef4444]/60" />
              <span>Your time (incorrect)</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2.5 h-2.5 rounded-sm bg-[rgba(255,255,255,0.1)]" />
              <span>Optimal limit</span>
            </div>
          </div>
        </motion.div>

        {/* Category Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="command-card p-6 mb-6"
        >
          <span className="text-label">Performance by Type</span>
          <div className="mt-4 space-y-3">
            {categoryData.map((cat) => (
              <div key={cat.category}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-[#f5f5f5] capitalize">
                    {cat.category}
                  </span>
                  <span className="text-xs font-mono text-[#737373]">
                    {cat.correct}/{cat.total} ({cat.accuracy}%)
                  </span>
                </div>
                <div className="h-2 rounded-full bg-[rgba(255,255,255,0.05)] overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${cat.accuracy}%`,
                      backgroundColor:
                        cat.accuracy >= 70
                          ? "#9eff00"
                          : cat.accuracy >= 50
                            ? "#f97316"
                            : "#ef4444",
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Question Review */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="command-card p-6 mb-6"
        >
          <span className="text-label">Question Review</span>
          <div className="mt-4 space-y-4">
            {results.answers.map((a, i) => (
              <div
                key={i}
                className={`p-4 rounded-lg border ${
                  a.isCorrect
                    ? "border-[#9eff00]/20 bg-[#9eff00]/5"
                    : "border-[#ef4444]/20 bg-[#ef4444]/5"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                      a.isCorrect
                        ? "bg-[#9eff00] text-[#050505]"
                        : "bg-[#ef4444] text-white"
                    }`}
                  >
                    {a.isCorrect ? (
                      <Check className="w-3 h-3" />
                    ) : (
                      <X className="w-3 h-3" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-[#f5f5f5] mb-2">
                      {a.question?.questionText}
                    </p>
                    <div className="flex items-center gap-4 text-[10px] text-[#737373] font-mono">
                      <span>Your answer: {a.question?.options[a.selectedAnswer]}</span>
                      {!a.isCorrect && (
                        <span className="text-[#9eff00]">
                          Correct: {a.question?.options[a.question.correctAnswer]}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {a.timeTakenSeconds}s
                      </span>
                    </div>
                    {!a.isCorrect && (
                      <p className="text-xs text-[#737373] mt-2 leading-relaxed">
                        {a.question?.explanation}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex items-center justify-center gap-3"
        >
          <Link
            to="/test"
            className="flex items-center gap-2 px-6 py-3 bg-[#9eff00] text-[#050505] rounded-lg font-medium text-sm hover:bg-[#b3ff33] transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            Take Another Test
          </Link>
          <Link
            to="/tutor"
            className="flex items-center gap-2 px-6 py-3 border border-[rgba(255,255,255,0.1)] text-[#f5f5f5] rounded-lg font-medium text-sm hover:bg-[rgba(255,255,255,0.05)] transition-colors"
          >
            <Brain className="w-4 h-4" />
            Ask AI Tutor
          </Link>
        </motion.div>
      </div>
    </div>
  );
}
