import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import {
  CheckCircle2,
  Circle,
  Clock,
  BookOpen,
  Brain,
  FileQuestion,
  RotateCcw,
  ChevronDown,
  ChevronUp,
  Lock,
  Zap,
  ArrowLeft,
  Target,
} from "lucide-react";

export default function StudyPlan() {
  const { user } = useAuth();
  const [expandedDay, setExpandedDay] = useState<number | null>(1);
  const [completedTasks, setCompletedTasks] = useState<Set<string>>(new Set());

  const { data: planData, isLoading } = trpc.studyPlan.getOrCreate.useQuery(
    undefined,
    { enabled: !!user }
  );
  const completeMutation = trpc.studyPlan.completeDay.useMutation();
  const utils = trpc.useUtils();

  const toggleTask = (_dayId: number, taskId: string) => {
    setCompletedTasks((prev) => {
      const next = new Set(prev);
      if (next.has(taskId)) {
        next.delete(taskId);
      } else {
        next.add(taskId);
      }
      return next;
    });
  };

  const saveDayProgress = (dayId: number) => {
    const dayTasks =
      planData?.days.find((d) => d.id === dayId)?.tasks || [];
    const completedIds = dayTasks
      .filter((t: any) => completedTasks.has(t.id) || t.completed)
      .map((t: any) => t.id);

    completeMutation.mutate(
      { dayId, taskIds: completedIds },
      {
        onSuccess: () => {
          utils.studyPlan.getOrCreate.invalidate();
          utils.studyPlan.progress.invalidate();
        },
      }
    );
  };

  const getTaskIcon = (type: string) => {
    switch (type) {
      case "lesson":
        return <BookOpen className="w-4 h-4" />;
      case "practice":
        return <Brain className="w-4 h-4" />;
      case "mock_test":
        return <FileQuestion className="w-4 h-4" />;
      case "review":
        return <RotateCcw className="w-4 h-4" />;
      default:
        return <Circle className="w-4 h-4" />;
    }
  };

  const getTaskColor = (type: string) => {
    switch (type) {
      case "lesson":
        return "#a855f7";
      case "practice":
        return "#9eff00";
      case "mock_test":
        return "#f97316";
      case "review":
        return "#3b82f6";
      default:
        return "#737373";
    }
  };

  if (!user) {
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Lock className="w-10 h-10 text-[#737373] mx-auto mb-3" />
          <p className="text-sm text-[#737373]">
            Sign in to access your 30-day study plan
          </p>
          <Link
            to="/login"
            className="inline-flex items-center gap-2 mt-3 px-4 py-2 bg-[#9eff00] text-[#050505] rounded-lg text-xs font-medium"
          >
            Sign In
          </Link>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#9eff00] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const plan = planData?.plan;
  const days = planData?.days || [];
  const currentDay = plan?.currentDay || 1;
  const totalCompleted = days.filter((d) => d.isCompleted).length;

  return (
    <div className="pt-16 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Link
            to="/"
            className="inline-flex items-center gap-1 text-xs text-[#737373] hover:text-[#f5f5f5] mb-4 transition-colors"
          >
            <ArrowLeft className="w-3 h-3" />
            Back to Dashboard
          </Link>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-3xl font-[Space_Grotesk] text-[#f5f5f5]">
              30-Day Study Plan
            </h1>
            <span className="px-2 py-0.5 rounded-full bg-[#9eff00]/10 border border-[#9eff00]/30 text-[10px] font-mono text-[#9eff00] uppercase">
              {totalCompleted}/30 Days
            </span>
          </div>
          <p className="text-sm text-[#737373]">
            A structured journey to psychometric mastery. Complete each day to build your skills progressively.
          </p>

          {/* Progress Bar */}
          <div className="mt-4 h-2 rounded-full bg-[rgba(255,255,255,0.05)] overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{
                width: `${(totalCompleted / 30) * 100}%`,
              }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="h-full bg-[#9eff00] rounded-full"
            />
          </div>
        </motion.div>

        {/* Week Labels */}
        <div className="grid grid-cols-4 gap-2 mb-6">
          {[
            { label: "Week 1", sub: "Foundation", color: "#9eff00" },
            { label: "Week 2", sub: "Building", color: "#a855f7" },
            { label: "Week 3", sub: "Intensify", color: "#f97316" },
            { label: "Week 4", sub: "Peak", color: "#3b82f6" },
          ].map((week, i) => (
            <div
              key={i}
              className="p-3 rounded-lg bg-[#0a0a0a] border border-[rgba(255,255,255,0.06)]"
            >
              <div
                className="text-xs font-mono font-medium mb-0.5"
                style={{ color: week.color }}
              >
                {week.label}
              </div>
              <div className="text-[10px] text-[#737373]">{week.sub}</div>
            </div>
          ))}
        </div>

        {/* Days Accordion */}
        <div className="space-y-3">
          {days.map((day, index) => {
            const isExpanded = expandedDay === day.id;
            const isCurrent = day.dayNumber === currentDay;
            const isCompleted = day.isCompleted;
            const isLocked = day.dayNumber > currentDay && !isCompleted;
            const weekNum = Math.floor(index / 7) + 1;

            return (
              <motion.div
                key={day.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.02 }}
                className={`command-card overflow-hidden ${
                  isCurrent ? "border-[#9eff00]/30" : ""
                }`}
              >
                {/* Day Header */}
                <button
                  onClick={() =>
                    !isLocked && setExpandedDay(isExpanded ? null : day.id)
                  }
                  className="w-full p-4 flex items-center gap-4 text-left"
                >
                  {isCompleted ? (
                    <CheckCircle2 className="w-5 h-5 text-[#9eff00] flex-shrink-0" />
                  ) : isCurrent ? (
                    <Target className="w-5 h-5 text-[#f97316] flex-shrink-0" />
                  ) : isLocked ? (
                    <Lock className="w-5 h-5 text-[#404040] flex-shrink-0" />
                  ) : (
                    <Circle className="w-5 h-5 text-[#737373] flex-shrink-0" />
                  )}

                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-[#737373]">
                        Day {day.dayNumber}
                      </span>
                      {isCurrent && (
                        <span className="px-1.5 py-0.5 rounded bg-[#f97316]/10 text-[#f97316] text-[9px] font-mono uppercase">
                          Current
                        </span>
                      )}
                      <span className="px-1.5 py-0.5 rounded bg-[rgba(255,255,255,0.05)] text-[#737373] text-[9px] font-mono">
                        W{weekNum}
                      </span>
                    </div>
                    <h3
                      className={`text-sm font-medium mt-0.5 ${
                        isLocked ? "text-[#404040]" : "text-[#f5f5f5]"
                      }`}
                    >
                      {day.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1 text-[10px] text-[#737373] font-mono">
                      <Clock className="w-3 h-3" />
                      {day.tasks?.reduce(
                        (acc: number, t: any) => acc + (t.durationMinutes || 0),
                        0
                      ) || 0}
                      m
                    </div>
                    {!isLocked &&
                      (isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-[#737373]" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-[#737373]" />
                      ))}
                  </div>
                </button>

                {/* Expanded Content */}
                <AnimatePresence>
                  {isExpanded && !isLocked && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 border-t border-[rgba(255,255,255,0.05)] pt-4">
                        {day.description && (
                          <p className="text-xs text-[#737373] mb-4 leading-relaxed">
                            {day.description}
                          </p>
                        )}

                        {/* Tasks */}
                        <div className="space-y-2">
                          {day.tasks?.map((task: any) => {
                            const taskDone =
                              task.completed || completedTasks.has(task.id);
                            return (
                              <div
                                key={task.id}
                                className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${
                                  taskDone
                                    ? "border-[#9eff00]/20 bg-[#9eff00]/5"
                                    : "border-[rgba(255,255,255,0.05)] bg-[#121212]"
                                }`}
                              >
                                <button
                                  onClick={() =>
                                    toggleTask(day.id, task.id)
                                  }
                                  className="flex-shrink-0"
                                >
                                  {taskDone ? (
                                    <CheckCircle2 className="w-5 h-5 text-[#9eff00]" />
                                  ) : (
                                    <Circle className="w-5 h-5 text-[#404040] hover:text-[#737373]" />
                                  )}
                                </button>

                                <div
                                  className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                                  style={{
                                    backgroundColor: `${getTaskColor(task.type)}15`,
                                    color: getTaskColor(task.type),
                                  }}
                                >
                                  {getTaskIcon(task.type)}
                                </div>

                                <div className="flex-1">
                                  <span
                                    className={`text-xs ${
                                      taskDone
                                        ? "text-[#737373] line-through"
                                        : "text-[#f5f5f5]"
                                    }`}
                                  >
                                    {task.title}
                                  </span>
                                </div>

                                <div className="flex items-center gap-1 text-[10px] text-[#737373] font-mono">
                                  <Clock className="w-3 h-3" />
                                  {task.durationMinutes}m
                                </div>

                                {task.type === "mock_test" && !taskDone && (
                                  <Link
                                    to="/test"
                                    className="px-3 py-1 rounded-md bg-[#9eff00]/10 text-[#9eff00] text-[10px] font-medium hover:bg-[#9eff00]/20 transition-colors"
                                  >
                                    Start
                                  </Link>
                                )}
                              </div>
                            );
                          })}
                        </div>

                        {/* Save Progress Button */}
                        <button
                          onClick={() => saveDayProgress(day.id)}
                          disabled={completeMutation.isPending}
                          className="mt-4 w-full py-2.5 bg-[#9eff00]/10 border border-[#9eff00]/30 text-[#9eff00] rounded-lg text-xs font-medium hover:bg-[#9eff00]/20 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                        >
                          {completeMutation.isPending ? (
                            <div className="w-3 h-3 border border-[#9eff00] border-t-transparent rounded-full animate-spin" />
                          ) : (
                            <Zap className="w-3 h-3" />
                          )}
                          Save Progress
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
