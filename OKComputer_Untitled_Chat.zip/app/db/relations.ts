import { relations } from "drizzle-orm";
import {
  users,
  categories,
  subTopics,
  questions,
  testSessions,
  sessionAnswers,
  userProgress,
  studyPlans,
  studyPlanDays,
  dailyStreaks,
  chatMessages,
} from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  testSessions: many(testSessions),
  userProgress: many(userProgress),
  studyPlans: many(studyPlans),
  dailyStreaks: many(dailyStreaks),
  chatMessages: many(chatMessages),
}));

export const categoriesRelations = relations(categories, ({ many }) => ({
  subTopics: many(subTopics),
  questions: many(questions),
  userProgress: many(userProgress),
}));

export const subTopicsRelations = relations(subTopics, ({ one, many }) => ({
  category: one(categories, {
    fields: [subTopics.categoryId],
    references: [categories.id],
  }),
  questions: many(questions),
}));

export const questionsRelations = relations(questions, ({ one, many }) => ({
  category: one(categories, {
    fields: [questions.categoryId],
    references: [categories.id],
  }),
  subTopic: one(subTopics, {
    fields: [questions.subTopicId],
    references: [subTopics.id],
  }),
  sessionAnswers: many(sessionAnswers),
}));

export const testSessionsRelations = relations(testSessions, ({ one, many }) => ({
  user: one(users, {
    fields: [testSessions.userId],
    references: [users.id],
  }),
  answers: many(sessionAnswers),
}));

export const sessionAnswersRelations = relations(sessionAnswers, ({ one }) => ({
  session: one(testSessions, {
    fields: [sessionAnswers.sessionId],
    references: [testSessions.id],
  }),
  question: one(questions, {
    fields: [sessionAnswers.questionId],
    references: [questions.id],
  }),
}));

export const userProgressRelations = relations(userProgress, ({ one }) => ({
  user: one(users, {
    fields: [userProgress.userId],
    references: [users.id],
  }),
  category: one(categories, {
    fields: [userProgress.categoryId],
    references: [categories.id],
  }),
}));

export const studyPlansRelations = relations(studyPlans, ({ one, many }) => ({
  user: one(users, {
    fields: [studyPlans.userId],
    references: [users.id],
  }),
  days: many(studyPlanDays),
}));

export const studyPlanDaysRelations = relations(studyPlanDays, ({ one }) => ({
  plan: one(studyPlans, {
    fields: [studyPlanDays.planId],
    references: [studyPlans.id],
  }),
}));

export const dailyStreaksRelations = relations(dailyStreaks, ({ one }) => ({
  user: one(users, {
    fields: [dailyStreaks.userId],
    references: [users.id],
  }),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  user: one(users, {
    fields: [chatMessages.userId],
    references: [users.id],
  }),
}));
