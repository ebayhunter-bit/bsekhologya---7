import { getDb } from "../api/queries/connection";
// TODO: import tables from "./schema"

async function seed() {
  getDb();
  console.log("Seeding database...");
  // Use the seed router API instead for initial data
  console.log("Use the /api/seed router for seeding initial data.");
  console.log("Done.");
  process.exit(0); // close MySQL connection pool
}

seed();
