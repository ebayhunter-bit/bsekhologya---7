import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  json,
  boolean,
  bigint,
  float,
  index,
} from "drizzle-orm/mysql-core";

// ─── Users (from auth scaffold) ───────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Categories (Numerical, Logical, Abstract) ────────────────────────────────
export const categories = mysqlTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  color: varchar("color", { length: 20 }).default("#9eff00"),
  icon: varchar("icon", { length: 50 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Category = typeof categories.$inferSelect;

// ─── SubTopics (e.g., "Number Sequences", "Percentage Change", "Pattern Recognition") ─
export const subTopics = mysqlTable("sub_topics", {
  id: serial("id").primaryKey(),
  categoryId: bigint("categoryId", { mode: "number", unsigned: true })
    .notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  slug: varchar("slug", { length: 200 }).notNull(),
  description: text("description"),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).default("medium"),
  order: int("order").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SubTopic = typeof subTopics.$inferSelect;

// ─── Questions ────────────────────────────────────────────────────────────────
export const questions = mysqlTable("questions", {
  id: serial("id").primaryKey(),
  categoryId: bigint("categoryId", { mode: "number", unsigned: true })
    .notNull(),
  subTopicId: bigint("subTopicId", { mode: "number", unsigned: true }),
  type: mysqlEnum("type", [
    "numerical_sequence",
    "percentage_change",
    "ratio_proportion",
    "data_interpretation",
    "abstract_pattern",
    "abstract_analogy",
    "logical_deduction",
    "syllogism",
    "verbal_analogy",
    "spatial_reasoning",
  ]).notNull(),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).notNull(),
  questionText: text("questionText").notNull(),
  options: json("options").$type<string[]>().notNull(),
  correctAnswer: int("correctAnswer").notNull(), // index into options array
  explanation: text("explanation").notNull(),
  timeLimitSeconds: int("timeLimitSeconds").default(90),
  // For abstract/spatial: SVG shape data
  shapeData: json("shapeData").$type<{
    grid?: { rows: number; cols: number };
    shapes?: Array<{
      type: string;
      color: string;
      size: number;
      rotation: number;
    }>;
    pattern?: string;
  }>(),
  tags: json("tags").$type<string[]>(),
  usedInTests: int("usedInTests").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("category_idx").on(table.categoryId),
  index("difficulty_idx").on(table.difficulty),
  index("type_idx").on(table.type),
]);

export type Question = typeof questions.$inferSelect;

// ─── Test Sessions ────────────────────────────────────────────────────────────
export const testSessions = mysqlTable("test_sessions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  categoryFilter: varchar("categoryFilter", { length: 100 }), // null = mixed
  difficultyMode: mysqlEnum("difficultyMode", [
    "adaptive",
    "easy",
    "medium",
    "hard",
    "mixed",
  ]).default("adaptive"),
  status: mysqlEnum("status", ["in_progress", "completed", "abandoned"])
    .default("in_progress")
    .notNull(),
  totalQuestions: int("totalQuestions").default(20),
  questionsAnswered: int("questionsAnswered").default(0),
  correctAnswers: int("correctAnswers").default(0),
  score: float("score").default(0), // percentage
  timeLimitMinutes: int("timeLimitMinutes").default(30),
  timeUsedSeconds: int("timeUsedSeconds").default(0),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  questionIds: json("questionIds").$type<number[]>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TestSession = typeof testSessions.$inferSelect;

// ─── Session Answers ──────────────────────────────────────────────────────────
export const sessionAnswers = mysqlTable("session_answers", {
  id: serial("id").primaryKey(),
  sessionId: bigint("sessionId", { mode: "number", unsigned: true }).notNull(),
  questionId: bigint("questionId", { mode: "number", unsigned: true }).notNull(),
  selectedAnswer: int("selectedAnswer").notNull(),
  isCorrect: boolean("isCorrect").notNull(),
  timeTakenSeconds: int("timeTakenSeconds").notNull(),
  answeredAt: timestamp("answeredAt").defaultNow().notNull(),
});

export type SessionAnswer = typeof sessionAnswers.$inferSelect;

// ─── User Progress (per category) ─────────────────────────────────────────────
export const userProgress = mysqlTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  categoryId: bigint("categoryId", { mode: "number", unsigned: true }).notNull(),
  subTopicId: bigint("subTopicId", { mode: "number", unsigned: true }),
  questionsAttempted: int("questionsAttempted").default(0),
  questionsCorrect: int("questionsCorrect").default(0),
  averageTimeSeconds: float("averageTimeSeconds").default(0),
  masteryLevel: mysqlEnum("masteryLevel", [
    "beginner",
    "developing",
    "proficient",
    "advanced",
    "mastered",
  ]).default("beginner"),
  lastStudiedAt: timestamp("lastStudiedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
}, (table) => [
  index("user_progress_user_idx").on(table.userId),
  index("user_progress_category_idx").on(table.categoryId),
]);

export type UserProgress = typeof userProgress.$inferSelect;

// ─── Study Plans ──────────────────────────────────────────────────────────────
export const studyPlans = mysqlTable("study_plans", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 200 }).default("30-Day Psychometric Mastery"),
  startDate: timestamp("startDate").defaultNow().notNull(),
  targetDate: timestamp("targetDate").notNull(),
  targetScore: int("targetScore").default(85),
  currentDay: int("currentDay").default(1),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StudyPlan = typeof studyPlans.$inferSelect;

// ─── Study Plan Days ──────────────────────────────────────────────────────────
export const studyPlanDays = mysqlTable("study_plan_days", {
  id: serial("id").primaryKey(),
  planId: bigint("planId", { mode: "number", unsigned: true }).notNull(),
  dayNumber: int("dayNumber").notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  focusAreas: json("focusAreas").$type<string[]>(),
  tasks: json("tasks").$type<
    Array<{
      id: string;
      title: string;
      type: "lesson" | "practice" | "mock_test" | "review";
      completed: boolean;
      durationMinutes: number;
      subTopicId?: number;
    }>
  >(),
  isCompleted: boolean("isCompleted").default(false),
  completedAt: timestamp("completedAt"),
  scheduledDate: timestamp("scheduledDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StudyPlanDay = typeof studyPlanDays.$inferSelect;

// ─── Daily Streaks ────────────────────────────────────────────────────────────
export const dailyStreaks = mysqlTable("daily_streaks", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  questionsAnswered: int("questionsAnswered").default(0),
  minutesStudied: int("minutesStudied").default(0),
  streakPoints: int("streakPoints").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DailyStreak = typeof dailyStreaks.$inferSelect;

// ─── AI Chat Messages ─────────────────────────────────────────────────────────
export const chatMessages = mysqlTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: text("content").notNull(),
  contextType: varchar("contextType", { length: 50 }), // "general", "question_explanation", "study_plan"
  contextId: bigint("contextId", { mode: "number", unsigned: true }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
